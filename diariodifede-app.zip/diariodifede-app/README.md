# Diario di Fede — App

## Deploy su Vercel (gratuito)

### PASSO 1 — Carica il progetto su GitHub
1. Vai su github.com e crea un account gratuito
2. Clicca "New repository" → nome: `diariodifede-app`
3. Carica tutti i file di questa cartella

### PASSO 2 — Collega a Vercel
1. Vai su vercel.com → Sign up con GitHub
2. Clicca "New Project" → seleziona `diariodifede-app`
3. Clicca "Deploy" (le impostazioni sono già corrette)

### PASSO 3 — Aggiungi la API Key di Anthropic
1. Nel progetto Vercel → Settings → Environment Variables
2. Aggiungi: `ANTHROPIC_API_KEY` = la tua chiave API
3. Rideploya il progetto

### PASSO 4 — Dominio personalizzato (opzionale)
1. Vercel → Settings → Domains
2. Aggiungi: `app.diariodifede.com`
3. Aggiungi il record CNAME sul tuo DNS

### PASSO 5 — Installa sul telefono come app
1. Apri l'URL dell'app su Safari (iOS) o Chrome (Android)
2. iOS: condividi → "Aggiungi a schermata Home"
3. Android: menu → "Installa app"

## Struttura file
```
diariodifede-app/
├── public/
│   ├── index.html    ← App completa
│   └── manifest.json ← PWA manifest
├── api/
│   ├── ask.js        ← API voce del Signore
│   └── articles.js   ← API articoli blog
├── vercel.json       ← Config routing
└── package.json
```

## Funzionalità
- 🏠 Home con versetto del giorno
- ✝️ La Voce del Signore (dialogo con Gesù via Claude AI)
- 📖 Feed articoli dal blog diariodifede.com
- 📅 Piano lettura 20 giorni
- 🔊 Ascolto audio articoli e versetti
- 🎙️ Input vocale (microfono)
- 📱 Installabile come app sul telefono
